define({
  root: {
    hintMessage: "Click map to get coordinate",
    defaultLabel: "Default Settings",
    computing: "computing...",
    latitudeLabel: "Latitude",
    longitudeLabel: "Longitude"
  },
  "zh-cn": true
});