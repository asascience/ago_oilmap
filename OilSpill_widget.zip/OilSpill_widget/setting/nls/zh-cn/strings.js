﻿define({
  placeholder: "输入框提示信息",
  name: "名称",
  singleLineFieldName: "查询字段",
  actions: "操作",
  warning: "错误的输入"
});